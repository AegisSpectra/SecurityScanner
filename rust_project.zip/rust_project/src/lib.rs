#[no_mangle]
pub extern "C" fn calculate_threat_score(input: *const c_char) -> i32 {
    // דוגמה בסיסית לפענוח:
    let c_str = unsafe {
        assert!(!input.is_null());
        CStr::from_ptr(input)
    };
    let description = c_str.to_str().unwrap_or("");
    
    // סימולציה של אלגוריתם הערכת סיכון
    if description.contains("explorer") {
        90
    } else if description.contains("suspicious") {
        70
    } else {
        20
    }
}
